package com.cotiviti.ccv.unification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

@Configuration
public class LdapConfiguration {

	@Autowired
	Environment env;

	@Bean
	public LdapContextSource contextSource() {
		LdapContextSource contextSource = new LdapContextSource();

		contextSource.setUrl("ldap://172.23.177.21:10389");
		contextSource.setBase("o=mojo");
		contextSource.setUserDn("uid=admin,ou=system");// ("ou=users,o=mojo");
		contextSource.setPassword("secret");
		contextSource.afterPropertiesSet();
		return contextSource;
	}

	@Bean
	public LdapTemplate ldapTemplate() {
		return new LdapTemplate(contextSource());
	}

}
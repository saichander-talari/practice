package com.cotiviti.ccv.unification.repository;

import org.springframework.data.repository.CrudRepository;

import com.cotiviti.ccv.unification.model.Employees;

public interface EmployeesRepository extends CrudRepository<Employees, Long> {

}

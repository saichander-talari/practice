package com.cotiviti.ccv.unification.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "TASKS")
public class Tasks {
	
	@Id
	@GeneratedValue
	@Column(name = "TASK_ID")
	private long taskId;
	
	@OneToOne
	@JoinColumn(name = "CLAIM_DETAIL_KEY")
	private ClaimDetails claimDetail;
	
	@ManyToOne
	@JoinColumn(name = "TASK_TYPE_ID")
	private TaskTypes taskType;
	
	@ManyToOne
	@JoinColumn(name = "AUDITOR_ID")
	private Auditors auditor;
	
	@Column(name = "START_DATE")
	private Date startDate;
	
	@Column(name = "END_DATE")
	private Date endDate;
	
	@Column(name = "CURRENT_10")
	private int current10;
	
	
	/**
	 * 
	 */
	public Tasks() {
		super();
	}


	/**
	 * @return the taskId
	 */
	public long getTaskId() {
		return taskId;
	}


	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(long taskId) {
		this.taskId = taskId;
	}



	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}


	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}


	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public ClaimDetails getClaimDetail() {
		return claimDetail;
	}


	public void setClaimDetail(ClaimDetails claimDetail) {
		this.claimDetail = claimDetail;
	}


	public TaskTypes getTaskType() {
		return taskType;
	}


	public void setTaskType(TaskTypes taskType) {
		this.taskType = taskType;
	}


	public Auditors getAuditor() {
		return auditor;
	}


	public void setAuditor(Auditors auditor) {
		this.auditor = auditor;
	}


	public int getCurrent10() {
		return current10;
	}


	public void setCurrent10(int current10) {
		this.current10 = current10;
	}




	
}

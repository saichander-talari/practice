package com.cotiviti.ccv.unification.service;

public interface LoginService {

	public boolean validateUser(String userName, String password);

}

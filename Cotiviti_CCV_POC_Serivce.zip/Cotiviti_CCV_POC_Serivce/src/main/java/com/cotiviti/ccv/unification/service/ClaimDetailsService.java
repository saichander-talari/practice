package com.cotiviti.ccv.unification.service;

import java.util.List;
import java.util.Map;

import com.cotiviti.ccv.unification.model.ClaimDetails;
import com.cotiviti.ccv.unification.model.TransferClaimDTO;

public interface ClaimDetailsService {

	public List<ClaimDetails> getAllClaimDetails();

	public Map<String, String> transferClaims(TransferClaimDTO transferClaimDTO);

	public List<ClaimDetails> getQueueDetailsByPayerAndTaskType(long payerId, long taskTypeId);

	public Map<String, Object> populateDetailsForTransfer(long payerId, long fromTaskTypeId);

	public Map<String, Map<Object, Object>> claimPayerTaskTypesCount();
}

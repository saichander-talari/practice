package com.cotiviti.ccv.unification.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cotiviti.ccv.unification.model.Auditors;
import com.cotiviti.ccv.unification.model.CCVConstants;
import com.cotiviti.ccv.unification.model.Employees;
import com.cotiviti.ccv.unification.service.AuditorService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class AuditorController {

	@Autowired
	AuditorService auditorService;

	@GetMapping("/auditors")
	public List<Auditors> getAllAuditors() {

		return auditorService.getAllAuditors();
	}

	@PostMapping("/auditors/addNewAuditor")
	public Map<String, String> addNewAuditor(@RequestBody Auditors auditors) {

		Map<String, String> response = new HashMap<>();
		String resultMessage = null;

		boolean res = auditorService.addNewAuditor(auditors);

		if (res) {
			if (auditors.getAuditorId() > 0) {
				resultMessage = auditors.getEmployee().getFirstName() + " " + auditors.getEmployee().getLastName()
						+ " updated successfully";
				response.put(CCVConstants.RESULT, resultMessage);

			} else {
				resultMessage = auditors.getEmployee().getFirstName() + " " + auditors.getEmployee().getLastName()
						+ " added successfully";
				response.put(CCVConstants.RESULT, resultMessage);
			}
		} else {
			resultMessage = CCVConstants.EMPLOYEE_DOES_NOT_EXISTS;
			response.put(CCVConstants.RESULT, resultMessage);
		}
		return response;
	}

	@PostMapping("/auditors/deleteAuditor")
	public Map<String, String> deleteAuditor(@RequestBody Auditors auditors) {
		Map<String, String> response = new HashMap<>();
		String resultMessage = null;

		Auditors result = null;
		result = auditorService.deleteAuditor(auditors);
		if (result != null) {
			resultMessage = result.getEmployee().getFirstName() + " " + result.getEmployee().getLastName()
					+ " deleted successfully";
			response.put(CCVConstants.RESULT, resultMessage);
		} else {
			resultMessage = " Error While Deleting Auditor";
			response.put(CCVConstants.RESULT, resultMessage);
		}
		return response;
	}

	@GetMapping("/fetchEmployeesList")
	public List<Employees> getAllEmployeesList() {

		return auditorService.getAllEmployeesList();
	}

}

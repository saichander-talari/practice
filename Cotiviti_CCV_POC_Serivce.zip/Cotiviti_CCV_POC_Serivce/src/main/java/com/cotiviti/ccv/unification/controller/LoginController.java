package com.cotiviti.ccv.unification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cotiviti.ccv.unification.model.CCVConstants;
import com.cotiviti.ccv.unification.model.ResponseStatus;
import com.cotiviti.ccv.unification.model.UserLogin;
import com.cotiviti.ccv.unification.service.LoginService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class LoginController {

	@Autowired
	private LoginService service;

	@PostMapping("/login")
	public ResponseStatus authenticate(@RequestBody UserLogin user) {

		String userName = user.getUsername().trim();

		String password = user.getPassword().trim();

		boolean result = service.validateUser(userName, password);
		ResponseStatus status = new ResponseStatus();
		if (result) {
			status.setUserName(user.getUsername());
			status.setStatusMessage(CCVConstants.SUCCESS);
			status.setStatusCode(HttpStatus.OK);

		} else {
			status.setUserName(user.getUsername());
			status.setStatusMessage(CCVConstants.FAILED);
			status.setStatusCode(HttpStatus.UNAUTHORIZED);

		}
		return status;

	}

}

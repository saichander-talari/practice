package com.cotiviti.ccv.unification.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class ControllerLogAspect {

	private static final Logger logger = LoggerFactory.getLogger(ControllerLogAspect.class);

	@Before("within(com.cotiviti..*)")
	public void beforeAdvice(JoinPoint jp) {

		logger.info(" Method:" + jp.getSignature().getName() + "() invoked ", jp.getTarget().getClass());

	}

	@AfterReturning("within(com.cotiviti..*)")
	public void afterAdvice(JoinPoint jp) {

		logger.info(
				" Method :" + jp.getSignature().getName() + "() executed successfully " + jp.getTarget().getClass());
	}

	@AfterThrowing(pointcut = "within(com.cotiviti..*)", throwing = "e")
	public void afterThrowingAdvice(JoinPoint jp, Throwable e) {

		StringWriter sw = null;
		PrintWriter pw = null;
		try {
			sw = new StringWriter();
			pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			/*
			 * LogUtil.appLog(new AppLogBean(LogConstants.LOG_LEVEL_ERROR,"Method Failed : "
			 * + jp.getSignature().getName() + " with arguments " +
			 * Arrays.toString(jp.getArgs()) + "\nand the full toString: " +
			 * jp.getSignature().toString() + "\nthe exception is: " +
			 * sw.getBuffer().toString(),jp.getTarget().getClass()));
			 */
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (pw != null)
				pw.close();
			try {
				if (sw != null)
					sw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}
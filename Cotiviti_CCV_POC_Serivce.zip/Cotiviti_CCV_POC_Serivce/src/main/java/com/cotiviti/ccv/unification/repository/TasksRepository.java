package com.cotiviti.ccv.unification.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cotiviti.ccv.unification.model.CCVConstants;
import com.cotiviti.ccv.unification.model.ClaimDetails;
import com.cotiviti.ccv.unification.model.Tasks;

public interface TasksRepository extends CrudRepository<Tasks, Long> {

	@Query(value = CCVConstants.QUERY_findByClaimDetailsId)
	public Tasks findByClaimDetailsId(int current10, long claimDetailsId);

}

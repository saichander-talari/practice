package com.cotiviti.ccv.unification.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PAYERS")
public class Payers {	
	
	@Id
	@GeneratedValue
	private long payerId;
	@Column(name = "PAYER_NAME")
	private String payerName;
	@Column(name = "PAYER_SHORT")
	private String payerShort;	
	
	/**
	 * 
	 */
	public Payers() {
		super();
	}


	

	/**
	 * @return the payerId
	 */
	public long getPayerId() {
		return payerId;
	}


	/**
	 * @param payerId the payerId to set
	 */
	public void setPayerId(long payerId) {
		this.payerId = payerId;
	}


	/**
	 * @return the payerName
	 */
	public String getPayerName() {
		return payerName;
	}


	/**
	 * @param payerName the payerName to set
	 */
	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}


	/**
	 * @return the payerShort
	 */
	public String getPayerShort() {
		return payerShort;
	}


	/**
	 * @param payerShort the payerShort to set
	 */
	public void setPayerShort(String payerShort) {
		this.payerShort = payerShort;
	}


}

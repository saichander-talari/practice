package com.cotiviti.ccv.unification.service;

import java.util.List;

import com.cotiviti.ccv.unification.model.Auditors;
import com.cotiviti.ccv.unification.model.Employees;

public interface AuditorService {

	public List<Auditors> getAllAuditors();

	public boolean addNewAuditor(Auditors auditors);

	public Auditors deleteAuditor(Auditors auditors);

	public List<Employees> getAllEmployeesList();

}

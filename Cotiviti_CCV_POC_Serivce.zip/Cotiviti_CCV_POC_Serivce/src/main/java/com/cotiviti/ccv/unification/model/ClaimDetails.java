package com.cotiviti.ccv.unification.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "CLAIM_DETAILS")
public class ClaimDetails {

	@Id
	@GeneratedValue
	private long claimDetailKey;

	@ManyToOne
	@JoinColumn(name = "TASK_TYPE_ID")
	private TaskTypes taskType;
	
	@OneToOne
	@JoinColumn(name = "PAYER_ID")
	private Payers payer;

	@Column(name = "COTIVITI_ID")
	private String cotivitiId;

	@Column(name = "CONCEPT_ID")
	private String conceptId;

	@Column(name = "CONCEPT_DESC")
	private String conceptDesc;

	@Column(name = "RULE_NAMES")
	private String ruleNames;

	@Column(name = "POLICY_NAMES")
	private String policyNames;

	@Column(name = "DRG")
	private String drg;

	@Column(name = "LENGTH_OF_STAY")
	private long lengthOfStay;

	@Column(name = "DAYS_TO_REVIEW")
	private long daysToReview;

	@Column(name = "GROUPER")
	private String grouper;

	@Column(name = "GWF")
	private String gwf;

	@Column(name = "QUEUE_AGE")
	private long queueAge;

	@Column(name = "CLAIM_STATUS")
	private String claimStatus;

	@Column(name = "PROJECT_NAME")
	private String projectName;

	@Column(name = "OCR_Y_N")
	private String ocrYN;

	@Column(name = "EXPECTED_ID_AMT")
	private long expectedId;

	@Column(name = "PROVIDER_NAME")
	private String providerName;

	@Column(name = "PROVIDER_STATE")
	private String providerState;

	@Column(name = "AUDIT_TYPE")
	private String auditType;

	@Column(name = "PRE_POST_PAY")
	private String prePostPay;

	@Column(name = "PLATFORM")
	private String platform;

	@Column(name = "INITIAL_AUDITOR_NAME")
	private String initialAuditorName;

	@Column(name = "INITIAL_AUDITOR_DECISION")
	private String initialAuditorDecision;

	@Column(name = "SECOND_PASS_AUDITOR_NAME")
	private String secondPassAuditorName;

	@Column(name = "SECOND_PASS_AUDIT_DECISION")
	private String secondPassAuditDecision;

	@Column(name = "QA_AUDITOR_NAME")
	private String qaAuditorName;

	@Column(name = "QA_AUDIT_DECISION")
	private String qaAuditDecission;

	@Column(name = "APPEAL1_AUDITOR_NAME")
	private String appeal1AuditorName;

	@Column(name = "APPEAL2_AUDITOR_NAME")
	private String appeal2AuditorName;

	@Column(name = "APPEAL3_AUDITOR_NAME")
	private String appeal3AuditorName;

	@Column(name = "APPEAL4_AUDITOR_NAME")
	private String appeal4AuditorName;
	
	@Transient
	private long count;

	/**
	 * 
	 */
	public ClaimDetails() {
		super();
	}

	/**
	 * @return the claimDetailKey
	 */
	public long getClaimDetailKey() {
		return claimDetailKey;
	}

	/**
	 * @param claimDetailKey the claimDetailKey to set
	 */
	public void setClaimDetailKey(long claimDetailKey) {
		this.claimDetailKey = claimDetailKey;
	}

	public TaskTypes getTaskType() {
		return taskType;
	}

	public void setTaskType(TaskTypes taskType) {
		this.taskType = taskType;
	}

	public Payers getPayer() {
		return payer;
	}

	public void setPayer(Payers payer) {
		this.payer = payer;
	}


	/**
	 * @return the conceptId
	 */
	public String getConceptId() {
		return conceptId;
	}

	/**
	 * @param conceptId the conceptId to set
	 */
	public void setConceptId(String conceptId) {
		this.conceptId = conceptId;
	}

	/**
	 * @return the conceptDesc
	 */
	public String getConceptDesc() {
		return conceptDesc;
	}

	/**
	 * @param conceptDesc the conceptDesc to set
	 */
	public void setConceptDesc(String conceptDesc) {
		this.conceptDesc = conceptDesc;
	}

	/**
	 * @return the ruleNames
	 */
	public String getRuleNames() {
		return ruleNames;
	}

	/**
	 * @param ruleNames the ruleNames to set
	 */
	public void setRuleNames(String ruleNames) {
		this.ruleNames = ruleNames;
	}

	/**
	 * @return the policyNames
	 */
	public String getPolicyNames() {
		return policyNames;
	}

	/**
	 * @param policyNames the policyNames to set
	 */
	public void setPolicyNames(String policyNames) {
		this.policyNames = policyNames;
	}

	/**
	 * @return the drg
	 */
	public String getDrg() {
		return drg;
	}

	/**
	 * @param drg the drg to set
	 */
	public void setDrg(String drg) {
		this.drg = drg;
	}



	/**
	 * @return the grouper
	 */
	public String getGrouper() {
		return grouper;
	}

	/**
	 * @param grouper the grouper to set
	 */
	public void setGrouper(String grouper) {
		this.grouper = grouper;
	}

	/**
	 * @return the gwf
	 */
	public String getGwf() {
		return gwf;
	}

	/**
	 * @param gwf the gwf to set
	 */
	public void setGwf(String gwf) {
		this.gwf = gwf;
	}

	

	
	/**
	 * @return the claimStatus
	 */
	public String getClaimStatus() {
		return claimStatus;
	}

	/**
	 * @param claimStatus the claimStatus to set
	 */
	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 * @return the ocrYN
	 */
	public String getOcrYN() {
		return ocrYN;
	}

	/**
	 * @param ocrYN the ocrYN to set
	 */
	public void setOcrYN(String ocrYN) {
		this.ocrYN = ocrYN;
	}

	
	
	/**
	 * @return the providerName
	 */
	public String getProviderName() {
		return providerName;
	}

	/**
	 * @param providerName the providerName to set
	 */
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	/**
	 * @return the providerState
	 */
	public String getProviderState() {
		return providerState;
	}

	/**
	 * @param providerState the providerState to set
	 */
	public void setProviderState(String providerState) {
		this.providerState = providerState;
	}

	/**
	 * @return the auditType
	 */
	public String getAuditType() {
		return auditType;
	}

	/**
	 * @param auditType the auditType to set
	 */
	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	/**
	 * @return the prePostPay
	 */
	public String getPrePostPay() {
		return prePostPay;
	}

	/**
	 * @param prePostPay the prePostPay to set
	 */
	public void setPrePostPay(String prePostPay) {
		this.prePostPay = prePostPay;
	}

	/**
	 * @return the platform
	 */
	public String getPlatform() {
		return platform;
	}

	/**
	 * @param platform the platform to set
	 */
	public void setPlatform(String platform) {
		this.platform = platform;
	}

	/**
	 * @return the initialAuditorName
	 */
	public String getInitialAuditorName() {
		return initialAuditorName;
	}

	/**
	 * @param initialAuditorName the initialAuditorName to set
	 */
	public void setInitialAuditorName(String initialAuditorName) {
		this.initialAuditorName = initialAuditorName;
	}

	/**
	 * @return the initialAuditorDecision
	 */
	public String getInitialAuditorDecision() {
		return initialAuditorDecision;
	}

	/**
	 * @param initialAuditorDecision the initialAuditorDecision to set
	 */
	public void setInitialAuditorDecision(String initialAuditorDecision) {
		this.initialAuditorDecision = initialAuditorDecision;
	}

	/**
	 * @return the secondPassAuditorName
	 */
	public String getSecondPassAuditorName() {
		return secondPassAuditorName;
	}

	/**
	 * @param secondPassAuditorName the secondPassAuditorName to set
	 */
	public void setSecondPassAuditorName(String secondPassAuditorName) {
		this.secondPassAuditorName = secondPassAuditorName;
	}

	/**
	 * @return the secondPassAuditDecision
	 */
	public String getSecondPassAuditDecision() {
		return secondPassAuditDecision;
	}

	/**
	 * @param secondPassAuditDecision the secondPassAuditDecision to set
	 */
	public void setSecondPassAuditDecision(String secondPassAuditDecision) {
		this.secondPassAuditDecision = secondPassAuditDecision;
	}

	/**
	 * @return the qaAuditorName
	 */
	public String getQaAuditorName() {
		return qaAuditorName;
	}

	/**
	 * @param qaAuditorName the qaAuditorName to set
	 */
	public void setQaAuditorName(String qaAuditorName) {
		this.qaAuditorName = qaAuditorName;
	}

	/**
	 * @return the qaAuditDecission
	 */
	public String getQaAuditDecission() {
		return qaAuditDecission;
	}

	/**
	 * @param qaAuditDecission the qaAuditDecission to set
	 */
	public void setQaAuditDecission(String qaAuditDecission) {
		this.qaAuditDecission = qaAuditDecission;
	}

	/**
	 * @return the appeal1AuditorName
	 */
	public String getAppeal1AuditorName() {
		return appeal1AuditorName;
	}

	/**
	 * @param appeal1AuditorName the appeal1AuditorName to set
	 */
	public void setAppeal1AuditorName(String appeal1AuditorName) {
		this.appeal1AuditorName = appeal1AuditorName;
	}

	/**
	 * @return the appeal2AuditorName
	 */
	public String getAppeal2AuditorName() {
		return appeal2AuditorName;
	}

	/**
	 * @param appeal2AuditorName the appeal2AuditorName to set
	 */
	public void setAppeal2AuditorName(String appeal2AuditorName) {
		this.appeal2AuditorName = appeal2AuditorName;
	}

	/**
	 * @return the appeal3AuditorName
	 */
	public String getAppeal3AuditorName() {
		return appeal3AuditorName;
	}

	/**
	 * @param appeal3AuditorName the appeal3AuditorName to set
	 */
	public void setAppeal3AuditorName(String appeal3AuditorName) {
		this.appeal3AuditorName = appeal3AuditorName;
	}

	/**
	 * @return the appeal4AuditorName
	 */
	public String getAppeal4AuditorName() {
		return appeal4AuditorName;
	}

	/**
	 * @param appeal4AuditorName the appeal4AuditorName to set
	 */
	public void setAppeal4AuditorName(String appeal4AuditorName) {
		this.appeal4AuditorName = appeal4AuditorName;
	}

	public String getCotivitiId() {
		return cotivitiId;
	}

	public void setCotivitiId(String cotivitiId) {
		this.cotivitiId = cotivitiId;
	}

	public long getLengthOfStay() {
		return lengthOfStay;
	}

	public void setLengthOfStay(long lengthOfStay) {
		this.lengthOfStay = lengthOfStay;
	}

	public long getDaysToReview() {
		return daysToReview;
	}

	public void setDaysToReview(long daysToReview) {
		this.daysToReview = daysToReview;
	}

	public long getQueueAge() {
		return queueAge;
	}

	public void setQueueAge(long queueAge) {
		this.queueAge = queueAge;
	}

	public long getExpectedId() {
		return expectedId;
	}

	public void setExpectedId(long expectedId) {
		this.expectedId = expectedId;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	

}

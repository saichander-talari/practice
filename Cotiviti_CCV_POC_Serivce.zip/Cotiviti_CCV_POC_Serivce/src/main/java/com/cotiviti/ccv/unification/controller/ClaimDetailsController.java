package com.cotiviti.ccv.unification.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cotiviti.ccv.unification.model.ClaimDetails;
import com.cotiviti.ccv.unification.model.TransferClaimDTO;
import com.cotiviti.ccv.unification.service.ClaimDetailsService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class ClaimDetailsController {

	@Autowired
	ClaimDetailsService claimDetailsService;

	@GetMapping("/getAllClaimDetails")
	public List<ClaimDetails> getAllClaimDetails() {

		return claimDetailsService.getAllClaimDetails();

	}

	@GetMapping("/getPayerTaskTypeCounts")
	@ResponseBody
	public Map<String, Map<Object, Object>> claimPayerTaskTypesCount() {

		return claimDetailsService.claimPayerTaskTypesCount();

	}

	@GetMapping("/qDetails/{payerId}/{taskTypeId}")
	public List<ClaimDetails> getQueueDetailsByPayer(@PathVariable("payerId") long payerId,
			@PathVariable("taskTypeId") long taskTypeId) {

		return claimDetailsService.getQueueDetailsByPayerAndTaskType(payerId, taskTypeId);

	}

	@PostMapping("/transferClaims")
	public Map<String, String> transferClaims(@RequestBody TransferClaimDTO transferClaimDTO) {

		return claimDetailsService.transferClaims(transferClaimDTO);

	}

	@GetMapping("/populateDetailsForTransfer/{payerId}/{fromTaskTypeId}")
	public Map<String, Object> populateDetailsForTransfer(@PathVariable("payerId") long payerId,
			@PathVariable("fromTaskTypeId") long fromTaskTypeId) {

		return claimDetailsService.populateDetailsForTransfer(payerId, fromTaskTypeId);

	}

}

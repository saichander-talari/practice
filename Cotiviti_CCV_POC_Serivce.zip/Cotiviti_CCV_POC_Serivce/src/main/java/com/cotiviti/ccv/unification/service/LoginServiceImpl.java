package com.cotiviti.ccv.unification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LdapTemplate ldapTemplate;

	@Override
	public boolean validateUser(String userName, String password) {

		AndFilter filter = new AndFilter();

		filter.and(new EqualsFilter("objectclass", "person"));
		filter.and(new EqualsFilter("uid", userName));

		boolean authenticated = ldapTemplate.authenticate(LdapUtils.emptyLdapName(), filter.toString(), password);

		return authenticated;
	}

}

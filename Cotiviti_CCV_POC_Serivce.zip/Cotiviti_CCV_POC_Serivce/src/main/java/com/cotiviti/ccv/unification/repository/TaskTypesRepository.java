package com.cotiviti.ccv.unification.repository;

import org.springframework.data.repository.CrudRepository;

import com.cotiviti.ccv.unification.model.TaskTypes;

public interface TaskTypesRepository extends CrudRepository<TaskTypes, Long> {

}

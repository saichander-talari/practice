package com.cotiviti.ccv.unification.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cotiviti.ccv.unification.model.Auditors;
import com.cotiviti.ccv.unification.model.Employees;
import com.cotiviti.ccv.unification.repository.AuditorsRepository;
import com.cotiviti.ccv.unification.repository.EmployeesRepository;

@Service
public class AuditorServiceImpl implements AuditorService {

	@Autowired
	AuditorsRepository auditorsRepository;

	@Autowired
	EmployeesRepository employeesRepository;

	public List<Auditors> getAllAuditors() {

		List<Auditors> auditors = new ArrayList<>();
		auditorsRepository.findAll().forEach(auditors::add);
		return auditors;
	}

	public boolean addNewAuditor(Auditors auditors) {

		if (!isEmployeeExist(auditors.getEmployee().getEmployeeId())) {
			return false;
		}

		Auditors result = auditorsRepository.save(auditors);

		Employees emp = new Employees();
		emp.setEmailId(
				auditors.getEmployee().getFirstName() + "." + auditors.getEmployee().getFirstName() + "@cotiviti.com");
		emp.setEmpLocation(auditors.getEmployee().getEmpLocation());
		emp.setEmployeeId(auditors.getEmployee().getEmployeeId());
		emp.setFirstName(auditors.getEmployee().getFirstName());
		emp.setLastName(auditors.getEmployee().getLastName());
		emp.setProbation(auditors.getEmployee().getProbation());
		emp.setReportingManager(auditors.getEmployee().getReportingManager());
		emp.setStatus(auditors.getEmployee().getStatus());

		Employees empResult = employeesRepository.save(emp);
		return true;
	}

	/**
	 * delete the existing User
	 * 
	 * @return boolean
	 */
	public Auditors deleteAuditor(Auditors auditors) {
		Auditors result = null;
		try {

			auditorsRepository.delete(auditors);
			result = auditors;
		} catch (Exception e) {
			e.printStackTrace();
			result = null;
		}
		return result;
	}

	public List<Employees> getAllEmployeesList() {
		List<Employees> employees = new ArrayList<>();
		employeesRepository.findAll().forEach(employees::add);
		return employees;
	}

	public boolean isEmployeeExist(long empId) {

		List<Employees> emps = getAllEmployeesList();
		for (Employees emp : emps) {
			if (empId == emp.getEmployeeId()) {
				return true;
			}
		}
		return false;
	}
}

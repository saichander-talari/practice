package com.cotiviti.ccv.unification.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TASK_TYPES")
public class TaskTypes {

	@Id
	@GeneratedValue
	private long taskTypeId;

	@Column(name = "TASK_ORDER")
	private long taskOrder;

	@Column(name = "TASK_NAME")
	private String taskName;

	@Column(name = "CURRENT_10")
	private int current10;

	public TaskTypes() {
		super();
	}

	public long getTaskOrder() {
		return taskOrder;
	}

	public void setTaskOrder(long taskOrder) {
		this.taskOrder = taskOrder;
	}

	public int getCurrent10() {
		return current10;
	}

	public void setCurrent10(int current10) {
		this.current10 = current10;
	}

	/**
	 * @return the taskTypeId
	 */
	public long getTaskTypeId() {
		return taskTypeId;
	}

	/**
	 * @param taskTypeId the taskTypeId to set
	 */
	public void setTaskTypeId(long taskTypeId) {
		this.taskTypeId = taskTypeId;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

}

package com.cotiviti.ccv.unification.repository;

import org.springframework.data.repository.CrudRepository;

import com.cotiviti.ccv.unification.model.Auditors;

public interface AuditorsRepository extends CrudRepository<Auditors, Long> {

}

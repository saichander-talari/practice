package com.cotiviti.ccv.unification.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEES")
public class Employees {
	
	@Id
	@GeneratedValue
	private int employeeId;
	
	@Column(name = "firstname ")
	private String firstName;	
	
	@Column(name = "reporting_manager")
	private String reportingManager;
	
	@Column(name = "lastname ")
	private String lastName;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "PROBATION")
	private String probation;
	
	@Column(name = "EMPLOYEE_LOCATION")
	private String empLocation;
	
	@Column(name = "status")
	private String status;
	
	/**
	 * 
	 */
	public Employees() {
		super();
	}


	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the reportingManager
	 */
	public String getReportingManager() {
		return reportingManager;
	}

	/**
	 * @param reportingManager the reportingManager to set
	 */
	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}

	
	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the probation
	 */
	public String getProbation() {
		return probation;
	}

	/**
	 * @param probation the probation to set
	 */
	public void setProbation(String probation) {
		this.probation = probation;
	}

	/**
	 * @return the empLocation
	 */
	public String getEmpLocation() {
		return empLocation;
	}

	/**
	 * @param empLocation the empLocation to set
	 */
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}	
}

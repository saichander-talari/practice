package com.cotiviti.ccv.unification.model;

public class CCVConstants {

	public final static String READY_TO_ASSIGN_TO_AUDITORS = "Ready To Assign To Auditors";
	public final static String READY_TO_ASSIGN_TO_SECOND_PASS = "Ready To Assign To Second Pass";
	public final static String READY_TO_ASSIGN_TO_QA = "Ready To Assign To QA";
	
	public final static String AUDITS_ASSIGNED = "Audits Assigned";
	public final static String AUDITS_ASSIGNED_SECOND_PASS = "Audits Assigned To Second Pass";
	public final static String AUDITS_ASSIGNED_QA = "Audits Assigned To QA";
	
	public final static String INITIAL_AUDITOR_ROLE = "Initial Auditor";
	public final static String QA_AUDITOR_ROLE = "QA Auditor";
	public final static String SECOND_PASS_AUDITOR_ROLE = "Second Pass Auditor";
	
	public final static String EMPLOYEE_DOES_NOT_EXISTS= " Employee does not exist.";
	
	public final static String RESULT= "Result";
	
	public final static String QUERY_findQClaimDetailsByPayerIdAndTaskTypeId = "select cd from ClaimDetails cd where cd.payer.payerId = ?1 and cd.taskType.taskTypeId = ?2 ";
	
	public final static String QUERY_findClaimPayerTaskTypesCount = "select count(cd) as count, cd.payer.payerId as payerId,cd.payer.payerShort as payerShort,cd.payer.payerName as payerName,cd.taskType.taskTypeId as taskTypeId,cd.taskType.taskName as taskName from ClaimDetails cd group by cd.payer.payerId,cd.taskType.taskTypeId";
	
	public final static String QUERY_findByClaimDetailsId = "select ts from Tasks ts where ts.current10=?1 and ts.claimDetail.claimDetailKey = ?2";
	
	public final static String SUCCESS="SUCCESS";
	public final static String FAILED="FAILED";
}

package com.cotiviti.ccv.unification.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.cotiviti.ccv.unification.model.CCVConstants;
import com.cotiviti.ccv.unification.model.ClaimDetails;

public interface ClaimDetailsRepository extends CrudRepository<ClaimDetails, Long> {

	@Query(value = CCVConstants.QUERY_findQClaimDetailsByPayerIdAndTaskTypeId)
	public List<ClaimDetails> findQClaimDetailsByPayerIdAndTaskTypeId(long payerId, long taskTypeId);

	@Query(value = CCVConstants.QUERY_findClaimPayerTaskTypesCount)
	public List<?> findClaimPayerTaskTypesCount();

}

package com.cotiviti.ccv.unification.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "AUDITORS")
public class Auditors {

	@Id
	@GeneratedValue
	private long auditorId;
	
	@OneToOne
	@JoinColumn(name = "EMPLOYEE_ID")
	private Employees employee;	
	
	@Column(name = "ROLE")
	private String role;
	
	@Column(name = "AUDIT_TYPE")
	private String auditType;
	
	@Column(name = "PRE_OR_POST")
	private String preOrPost;
	
	@Column(name = "POST")
	private String post;
	
	@Column(name = "LOB")
	private String lob;
	
	@Column(name = "APPEAL_LEVEL")
	private String appealLevel;
	
	@Column(name = "STATE")
	private String state;
	
	@ManyToOne
	@JoinColumn(name = "PAYER_ID")
	private Payers payer;
	
	@Column(name = "STATUS")
	private String status;

	/**
	 * 
	 */
	public Auditors() {
		super();
	}	



	/**
	 * @return the auditorId
	 */
	public long getAuditorId() {
		return auditorId;
	}

	/**
	 * @param auditorId the auditorId to set
	 */
	public void setAuditorId(long auditorId) {
		this.auditorId = auditorId;
	}

	/**
	 * @return the employee
	 */
	public Employees getEmployee() {
		return employee;
	}

	/**
	 * @param employee the employee to set
	 */
	public void setEmployee(Employees employee) {
		this.employee = employee;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the auditType
	 */
	public String getAuditType() {
		return auditType;
	}

	/**
	 * @param auditType the auditType to set
	 */
	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	/**
	 * @return the preOrPost
	 */
	public String getPreOrPost() {
		return preOrPost;
	}

	/**
	 * @param preOrPost the preOrPost to set
	 */
	public void setPreOrPost(String preOrPost) {
		this.preOrPost = preOrPost;
	}

	/**
	 * @return the post
	 */
	public String getPost() {
		return post;
	}

	/**
	 * @param post the post to set
	 */
	public void setPost(String post) {
		this.post = post;
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the appealLevel
	 */
	public String getAppealLevel() {
		return appealLevel;
	}

	/**
	 * @param appealLevel the appealLevel to set
	 */
	public void setAppealLevel(String appealLevel) {
		this.appealLevel = appealLevel;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the payer
	 */
	public Payers getPayer() {
		return payer;
	}

	/**
	 * @param payer the payer to set
	 */
	public void setPayer(Payers payer) {
		this.payer = payer;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	
}

package com.cotiviti.ccv.unification.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cotiviti.ccv.unification.model.Auditors;
import com.cotiviti.ccv.unification.model.CCVConstants;
import com.cotiviti.ccv.unification.model.ClaimDetails;
import com.cotiviti.ccv.unification.model.TaskTypes;
import com.cotiviti.ccv.unification.model.Tasks;
import com.cotiviti.ccv.unification.model.TransferClaimDTO;
import com.cotiviti.ccv.unification.repository.AuditorsRepository;
import com.cotiviti.ccv.unification.repository.ClaimDetailsRepository;
import com.cotiviti.ccv.unification.repository.TaskTypesRepository;
import com.cotiviti.ccv.unification.repository.TasksRepository;

@Service
public class ClaimDetailsServiceImpl implements ClaimDetailsService {

	@Autowired
	ClaimDetailsRepository claimDetailsRepository;

	@Autowired
	TaskTypesRepository taskTypesRepository;

	@Autowired
	TasksRepository tasksRepository;

	@Autowired
	AuditorsRepository auditorsRepository;

	public List<ClaimDetails> getAllClaimDetails() {

		List<ClaimDetails> claimDetails = new ArrayList<>();
		claimDetailsRepository.findAll().forEach(claimDetails::add);

		return claimDetails;

	}

	public Map<String, Map<Object, Object>> claimPayerTaskTypesCount() {

		List<?> dashObj = claimDetailsRepository.findClaimPayerTaskTypesCount();

		Map<String, Map<Object, Object>> resMap = new HashMap<>();

		for (int j = 0; j < dashObj.size(); j++) {
			Object[] obj = (Object[]) dashObj.get(j);
			Map<Object, Object> map = null;
			if (resMap.containsKey(String.valueOf((obj[2])))) {
				map = resMap.get(String.valueOf((obj[2])));
			} else {
				map = new HashMap<>();
			}
			if ((obj[1].toString()).equalsIgnoreCase(String.valueOf(map.get("payerId")))) {

				Map<String, Object> innerMap = new HashMap<>();
				innerMap.put("taskTypeName", obj[5].toString());
				innerMap.put("count", Long.parseLong(obj[0].toString()));

				map.put(Long.parseLong(obj[4].toString()), innerMap);
				resMap.put(String.valueOf(obj[2]), map);
			} else {
				map.put("payerShortName", obj[2].toString());
				map.put("payerId", Long.parseLong(obj[1].toString()));
				Map<String, Object> innerMap = new HashMap<>();
				innerMap.put("taskTypeName", obj[5].toString());
				innerMap.put("count", Long.parseLong(obj[0].toString()));
				map.put(Long.parseLong(obj[4].toString()), innerMap);
				resMap.put(String.valueOf(obj[2]), map);
			}

		}

		return resMap;
	}

	public List<ClaimDetails> getQueueDetailsByPayerAndTaskType(long payerId, long taskTypeId) {

		List<ClaimDetails> listClaims = claimDetailsRepository.findQClaimDetailsByPayerIdAndTaskTypeId(payerId,
				taskTypeId);

		return listClaims;
	}

	public ClaimDetails getClaimDetailsById(int id) {

		Optional<ClaimDetails> findResult = claimDetailsRepository.findById((long) id);

		if (findResult.isPresent()) {
			return findResult.get();
		} else {
			return null;
		}
	}

	public ClaimDetails getClaimDetailsById(long id) {

		Optional<ClaimDetails> findResult = claimDetailsRepository.findById(id);

		if (findResult.isPresent()) {
			return findResult.get();
		} else {
			return null;
		}
	}

	public TaskTypes getTaskTypeById(long id) {

		Optional<TaskTypes> findResult = taskTypesRepository.findById(id);

		if (findResult.isPresent()) {
			return findResult.get();
		} else {
			return null;
		}
	}

	public Auditors getAuditorById(long id) {

		Optional<Auditors> findResult = auditorsRepository.findById(id);

		if (findResult.isPresent()) {
			return findResult.get();
		} else {
			return null;
		}
	}

	public Map<String, String> transferClaims(TransferClaimDTO transferClaimDTO) {

		Map<String, String> resMap = new HashMap<>();
		int successCount = 0;
		String resMsg = validateTransferClaimDTO(transferClaimDTO);

		if (!resMsg.isEmpty()) {
			resMap.put(CCVConstants.RESULT, resMsg);
			resMap.put("successCount", "" + successCount);
			return resMap;
		}

		return transferClaimsOperation(transferClaimDTO);

	}

	private Map<String, String> transferClaimsOperation(TransferClaimDTO transferClaimDTO) {

		Map<String, String> resMap = new HashMap<>();
		int successCount = 0;
		String resMsg = "";
		String operationType = "";

		for (Long claimId : transferClaimDTO.getClaimIds()) {
			ClaimDetails claimDetails = getClaimDetailsById(claimId);
			if (null == claimDetails) {
				resMsg = "There is no claim Record exist with given Id.";
				resMap.put(CCVConstants.RESULT, resMsg);
				resMap.put("successCount", "" + successCount);
				return resMap;
			}

			int current = 1;
			Tasks task = tasksRepository.findByClaimDetailsId(current, claimId);
			/*
			 * if(null == task) { resMsg =
			 * "There is no Record exist in Tasks Table with given claimId.";
			 * resMap.put("Result", resMsg); resMap.put("successCount", "" + successCount);
			 * return resMap; }
			 */

			TaskTypes newTaskType = getTaskTypeById(transferClaimDTO.getToQ());
			if (null == newTaskType) {
				resMsg = "Invalid Task_Type.";
				resMap.put(CCVConstants.RESULT, resMsg);
				resMap.put("successCount", "" + successCount);
				return resMap;
			}

			Auditors auditor = null;
			if (0 < transferClaimDTO.getAuditorId()) {
				auditor = getAuditorById(transferClaimDTO.getAuditorId());
				if (null == auditor) {
					resMsg = "Invalid Auditor_Id.";
					resMap.put(CCVConstants.RESULT, resMsg);
					resMap.put("successCount", "" + successCount);
					return resMap;
				}
			}

			// updating the old task record
			if (null != task) {
				task.setCurrent10(0);
				;
				task.setEndDate(new Date());
				tasksRepository.save(task);
			}
			// update claim details table record with new task type id

			if (transferClaimDTO.getToQ() == 2) {
				if (transferClaimDTO.getFromQ() == 1) {
					operationType = "Queue";
				} else {
					operationType = "Auditor";
				}

				claimDetails.setInitialAuditorName(makeFirstAlphabetCapital(auditor.getEmployee().getFirstName()) + " "
						+ makeFirstAlphabetCapital(auditor.getEmployee().getLastName()));
			} else if (transferClaimDTO.getToQ() == 4) {
				if (transferClaimDTO.getFromQ() == 3) {
					operationType = "Auditor";
				}
				claimDetails.setSecondPassAuditorName(makeFirstAlphabetCapital(auditor.getEmployee().getFirstName())
						+ " " + makeFirstAlphabetCapital(auditor.getEmployee().getLastName()));
			} else if (transferClaimDTO.getToQ() == 6) {
				if (transferClaimDTO.getFromQ() == 5) {
					operationType = "Auditor";
				}

				claimDetails.setQaAuditorName(makeFirstAlphabetCapital(auditor.getEmployee().getFirstName()) + " "
						+ makeFirstAlphabetCapital(auditor.getEmployee().getLastName()));
			} else if (transferClaimDTO.getToQ() == 1) {
				operationType = "Queue";
				claimDetails.setQaAuditorName("");
				claimDetails.setSecondPassAuditorName("");
				claimDetails.setInitialAuditorName("");
			} else if (transferClaimDTO.getToQ() == 3) {
				operationType = "Queue";
				claimDetails.setQaAuditorName("");
				claimDetails.setSecondPassAuditorName("");
			} else if (transferClaimDTO.getToQ() == 5) {
				operationType = "Queue";
				claimDetails.setSecondPassAuditorName("");
				claimDetails.setQaAuditorName("");
			}
			claimDetails.setTaskType(newTaskType);
			claimDetailsRepository.save(claimDetails);

			// insert a new record with new task type id, start date as today date
			// current_status as 1
			Tasks newTask = new Tasks();
			// newTask.setTaskId(task.getTaskId()+1);
			newTask.setAuditor(auditor);
			newTask.setCurrent10(1);
			newTask.setStartDate(new Date());
			newTask.setTaskType(newTaskType);
			newTask.setClaimDetail(claimDetails);
			tasksRepository.save(newTask);

			resMsg = "Claims have been successfully transferred";
			successCount++;
		}

		resMap.put(CCVConstants.RESULT, resMsg);
		resMap.put("successCount", "" + successCount);
		resMap.put("operationType", operationType);

		return resMap;
	}

	private static String makeFirstAlphabetCapital(String input) {
		if (null != input) {
			StringBuffer sb = new StringBuffer(input);

			String temp = input.substring(0, 1);
			temp = temp.toUpperCase();
			char upChar = temp.charAt(0);
			sb.setCharAt(0, upChar);
			return sb.toString();
		} else {
			return input;
		}
	}

	public List<Map<String, String>> getAuditorsByRole(String role, long payerId) {
		List<Auditors> auditors = new ArrayList<>();
		List<Map<String, String>> filteredAuditors = new ArrayList<>();

		auditorsRepository.findAll().forEach(auditors::add);
		for (Auditors auditor : auditors) {
			if (role.equalsIgnoreCase(auditor.getRole()) && payerId == auditor.getPayer().getPayerId()) {
				Map<String, String> auditorinfo = new HashMap<>();
				auditorinfo.put("auditorName", makeFirstAlphabetCapital(auditor.getEmployee().getFirstName()) + " "
						+ makeFirstAlphabetCapital(auditor.getEmployee().getLastName()));
				auditorinfo.put("auditorId", String.valueOf(auditor.getAuditorId()));
				filteredAuditors.add(auditorinfo);
			}
		}
		return filteredAuditors;
	}

	public Map<String, Object> populateDetailsForTransfer(long payerId, long fromTaskTypeId) {

		Map<String, Object> resultMap = new HashMap<>();
		List<Map<String, String>> listUser = new ArrayList<>();
		List<TaskTypes> toTaskType = new ArrayList<>();
		Map<String, String> auditorinfo = new HashMap<>();

		if (1 == fromTaskTypeId) {

			listUser = getAuditorsByRole(CCVConstants.INITIAL_AUDITOR_ROLE, payerId);
			// toTaskType.add();

		} else if (2 == fromTaskTypeId) {

			listUser = getAuditorsByRole(CCVConstants.INITIAL_AUDITOR_ROLE, payerId);
			// toTaskType.add(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			TaskTypes taskType = new TaskTypes();
			taskType.setTaskName(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			taskType.setTaskTypeId(1);
			toTaskType.add(taskType);

		} else if (3 == fromTaskTypeId) {

			listUser = getAuditorsByRole(CCVConstants.SECOND_PASS_AUDITOR_ROLE, payerId);

			TaskTypes taskType = new TaskTypes();
			taskType.setTaskName(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			taskType.setTaskTypeId(1);
			toTaskType.add(taskType);

			TaskTypes taskType2 = new TaskTypes();
			taskType2.setTaskName(CCVConstants.READY_TO_ASSIGN_TO_QA);
			taskType2.setTaskTypeId(5);
			toTaskType.add(taskType2);

			// toTaskType.add(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			// toTaskType.add(CCVConstants.READY_TO_ASSIGN_TO_QA);

		} else if (5 == fromTaskTypeId) {

			listUser = getAuditorsByRole(CCVConstants.QA_AUDITOR_ROLE, payerId);
			TaskTypes taskType = new TaskTypes();
			taskType.setTaskName(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			taskType.setTaskTypeId(1);
			toTaskType.add(taskType);

			TaskTypes taskType2 = new TaskTypes();
			taskType2.setTaskName(CCVConstants.READY_TO_ASSIGN_TO_SECOND_PASS);
			taskType2.setTaskTypeId(3);
			toTaskType.add(taskType2);

			// toTaskType.add(CCVConstants.READY_TO_ASSIGN_TO_AUDITORS);
			// toTaskType.add(CCVConstants.READY_TO_ASSIGN_TO_SECOND_PASS);

		}
		resultMap.put("auditors", listUser);
		resultMap.put("toTaskTypes", toTaskType);

		return resultMap;
	}

	private String validateTransferClaimDTO(TransferClaimDTO transferClaimDTO) {
		String result = "";

		if (transferClaimDTO != null) {

			if (transferClaimDTO.getClaimIds() != null && transferClaimDTO.getClaimIds().length <= 0) {
				result = "Select at least 1 claim to perform this operation";
				return result;
			}

			if (transferClaimDTO.getIsQueueChecked().equalsIgnoreCase("true")) {

				/*
				 * if( transferClaimDTO.getFromQ() > 0) { if( (transferClaimDTO.getFromQ() != 1
				 * ) && (transferClaimDTO.getFromQ() != 2) ) { result =
				 * "From_Queue name is required"; } }
				 */

				if (transferClaimDTO.getToQ() > 0) {
					if (transferClaimDTO.getToQ() != 1 && transferClaimDTO.getToQ() != 2
							&& transferClaimDTO.getToQ() != 3 && transferClaimDTO.getToQ() != 4
							&& transferClaimDTO.getToQ() != 5 && transferClaimDTO.getToQ() != 6) {
						result = "Transfer to_Queue is required ";
					}
				}

			} else if (transferClaimDTO.getIsQueueChecked().equalsIgnoreCase("false")) {

				if (transferClaimDTO.getFromQ() == 1) {
					transferClaimDTO.setToQ(2);
				} else if (transferClaimDTO.getFromQ() == 3) {
					transferClaimDTO.setToQ(4);
				} else if (transferClaimDTO.getFromQ() == 5) {
					transferClaimDTO.setToQ(6);
				} else if (transferClaimDTO.getFromQ() == 2) {
					transferClaimDTO.setToQ(2);
				} else if (transferClaimDTO.getFromQ() == 4) {
					transferClaimDTO.setToQ(4);
				} else if (transferClaimDTO.getFromQ() == 6) {
					transferClaimDTO.setToQ(6);
				}

				if (transferClaimDTO.getAuditorId() < 0) {
					result = "Assign to Auditor is required";
				}
			}
		}
		return result;

	}

}

package com.cotiviti.ccv.unification.model;

import java.io.Serializable;

public class TransferClaimDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 148329485423L;
	
	private Long[] claimIds;
	private int fromQ;
	private int toQ;
	private int auditorId;
	private String isQueueChecked;

	public String getIsQueueChecked() {
		return isQueueChecked;
	}

	public void setIsQueueChecked(String isQueueChecked) {
		this.isQueueChecked = isQueueChecked;
	}

	public Long[] getClaimIds() {
		return claimIds;
	}

	public void setClaimIds(Long[] claimIds) {
		this.claimIds = claimIds;
	}

	public int getFromQ() {
		return fromQ;
	}

	public void setFromQ(int fromQ) {
		this.fromQ = fromQ;
	}

	public int getToQ() {
		return toQ;
	}

	public void setToQ(int toQ) {
		this.toQ = toQ;
	}

	public int getAuditorId() {
		return auditorId;
	}

	public void setAuditorId(int auditorId) {
		this.auditorId = auditorId;
	}

}

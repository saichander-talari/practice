package com.cotiviti.ccv.unification.model;

import org.springframework.http.HttpStatus;

public class ResponseStatus {
	
	private String userName;
	
	private String statusMessage;
	
	private HttpStatus statusCode;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

}

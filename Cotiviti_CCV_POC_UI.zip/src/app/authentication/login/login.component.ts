import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { Router } from '@angular/router';
import { fadeInOut } from '../../router.animations';
import { environment } from '../../../environments/environment';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as sha256 from './sha-encrypt.js';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [fadeInOut()]
})
export class LoginComponent implements OnInit {
  loginData = {
    username: '',
    password: ''
  };
  loginForm: FormGroup;
  submitted = false;
  errosMsg = false;
  alert = false;
  alertData;
  constructor(
    private HttpConnector: HttpConnectorService,
    public router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', [Validators.required]]
    });
    localStorage.removeItem('transferdata');
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  // Submit form
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    // encrypting password
    this.loginForm.value['password'] = sha256.encrypt(this.loginForm.value['password']);

    this.HttpConnector.postRequest(
      environment.Login,
      this.loginForm.value
    ).subscribe(response => {
      // if success allow user to proceed
      if (response.statusCode == 'OK') {
        this.errosMsg = false;
        const name = response.userName
          .match(/^([^@]*)@/)[1]
          .replace(/\./g, ' ');
        localStorage.setItem('name', name); // setting username
        localStorage.setItem('isLoggedin', 'true'); // setting session
        this.router.navigate(['secure']); // redirecting to dashboard
      } else {
        this.alertFn('  Username or Password is incorrect  ');
        this.errosMsg = true;
      }
    });
  }

  // Reusable alert function for showing errors
  alertFn(data) {
    this.alert = true;
    this.alertData = data;
  }
}

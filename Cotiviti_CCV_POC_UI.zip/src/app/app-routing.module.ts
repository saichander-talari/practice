import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthResolver } from './core/services/auth.resolver';
import { MainScreenModule } from './main-screen/main-screen.module';
import { AuthenticationModule } from './authentication/authentication.module';
import { AuthGuard } from './shared/guard';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'secure',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => AuthenticationModule,
    resolve: {
      token: AuthResolver
    }
  },
  {
    path: 'secure',
    loadChildren: () => MainScreenModule,
    canActivate: [AuthGuard]
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
import { TestBed, async, inject } from '@angular/core/testing';

import { ConfirmWindowGuard } from './confirm-window.guard';

describe('ConfirmWindowGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConfirmWindowGuard]
    });
  });

  it('should ...', inject([ConfirmWindowGuard], (guard: ConfirmWindowGuard) => {
    expect(guard).toBeTruthy();
  }));
});

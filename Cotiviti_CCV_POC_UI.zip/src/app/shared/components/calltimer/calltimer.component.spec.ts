import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalltimerComponent } from './calltimer.component';

describe('CalltimerComponent', () => {
  let component: CalltimerComponent;
  let fixture: ComponentFixture<CalltimerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalltimerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalltimerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-test',
  templateUrl: './shared-test.component.html',
  styleUrls: ['./shared-test.component.scss']
})
export class SharedTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

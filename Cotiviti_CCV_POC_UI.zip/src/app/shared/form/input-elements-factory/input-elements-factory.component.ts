import { Component, OnInit } from '@angular/core';
import { Input } from "@angular/core";
import { InputBase } from "src/app/shared/form/service/input-base";
import { FormGroup } from "@angular/forms";

@Component({
  selector: 'app-input-elements-factory',
  templateUrl: './input-elements-factory.component.html',
  styleUrls: ['./input-elements-factory.component.css']
})
export class InputElementsFactoryComponent implements OnInit {
  @Input() inputElement: InputBase<any>;
  @Input() form: FormGroup;
  @Input() formCntrlName: number;
  constructor() { }

  ngOnInit() {
    let tttggg = this.formCntrlName;
    let ttt=this.form.controls[this.inputElement.key];
  }
get isValid() { return this.form.controls[this.inputElement.key].valid; }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputElementsFactoryComponent } from './input-elements-factory.component';

describe('InputElementsFactoryComponent', () => {
  let component: InputElementsFactoryComponent;
  let fixture: ComponentFixture<InputElementsFactoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputElementsFactoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputElementsFactoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

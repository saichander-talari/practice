import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';
import { fadeInOut } from '../../router.animations';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IfStmt } from '../../../../node_modules/@angular/compiler';
declare var $: any;
@Component({
  selector: 'app-user-setup',
  templateUrl: './user-setup.component.html',
  styleUrls: ['./user-setup.component.scss'],
  animations: [fadeInOut()]
})
export class UserSetupComponent implements OnInit {
  users: any;
  smartSearchData: any = [];
  registerForm: FormGroup;
  submitted = false;
  states: any;
  lobs: any;
  deleteUserData: any;
  alert = false;
  alertData;
  alertType = true;
  constructor(private HttpConnector: HttpConnectorService, private formBuilder: FormBuilder) { }
  ngOnInit() {
    this.usersList(); // get list of users
    this.formReg(); // build form (reactive form is used)
    this.getSmartSerachData(); // get smart search data
    // on model close enable delete button of respective row in table
    $('#deleteModal').on('hidden.bs.modal', () => this.deleteUserData = '');
  }

  // smart search
  getSmartSerachData() {
    this.HttpConnector.getRequest(environment.Smart_Search).subscribe(response => {
      this.smartSearchData = response;
    });
  }
  changeSmartSearchData() {
    this.smartSearchData.filter(elemt => {
      if (this.registerForm.controls['empId'].value == elemt.employeeId) {
        this.registerForm.controls['empFirstName'].setValue(elemt.firstName);
        this.registerForm.controls['empLastName'].setValue(elemt.lastName);
      }
    });
  }

  // reusable form (create/edit)
  formReg(val?) {
    // building form group, if there is values then it bind values for form (used for edit) else it create fresh form
    this.registerForm = this.formBuilder.group({
      id: [val ? val.id : '', ''],
      empId: [val ? val.empId : '', Validators.required],
      empFirstName: [val ? val.empFirstName : '', Validators.required],
      empLastName: [val ? val.empLastName : '', Validators.required],
      role: [val ? val.role : '', Validators.required],
      reportingManager: [val ? val.reportingManager : '', Validators.required],
      auditType: [val ? val.auditType : '', Validators.required],
      probation: [val ? val.probation : '', Validators.required],
      employeeLocation: [val ? val.employeeLocation : '', Validators.required],
      preOrPost: [val ? val.preOrPost : '', ''],
      post: [val ? val.post : '', ''],
      payer: [val ? val.payer : '', Validators.required],
      state: [val ? val.state : '', Validators.required],
      lob: [val ? val.lob : '', Validators.required],
      appealLevel: [val ? val.appealLevel : '', Validators.required],
    });

    // cascading dropdown functionality
    if (val && val.payer === 'ANTM') {
      this.states = [{ value: "New York", key: "New York" }]
      this.lobs = [{ value: "Medicaid", key: "Medicaid" }, { value: "Medicare", key: "Medicare" }];
      this.registerForm.get('lob').setValidators([Validators.required]);
      this.registerForm.get('state').setValue(val.state);
      this.registerForm.get('lob').setValue(val.lob)
    } else if (val && val.payer === 'BCBSMA') {
      this.states = [{ value: "Massachusetts", key: "Massachusetts" }, { value: "New York", key: "New York" }];
      this.lobs = [{ value: "Medicaid", key: "Medicaid" }];
      this.registerForm.get('lob').setValidators([Validators.required]);
      this.registerForm.get('state').setValue(val.state);
      this.registerForm.get('lob').setValue(val.lob)
    } else if (val && val.payer === 'UHG') {
      this.states = [{ value: "California", key: "California" }, { value: "Medicare", key: "Medicare" }];
      this.lobs = [{ value: "Commercial/Other", key: "Commercial/Other" }];
      this.registerForm.get('lob').clearValidators();
      this.registerForm.get('lob').updateValueAndValidity();
      this.registerForm.get('state').setValue(val.state)
    }
    if (val && val.role != 'Audit Manager') {
      this.registerForm.get('appealLevel').enable();
      this.registerForm.get('appealLevel').setValidators([Validators.required]);
    } else {
      this.registerForm.get('appealLevel').disable();
      this.registerForm.get('appealLevel').setValue("0")
      this.registerForm.get('appealLevel').clearValidators();
    }
  }
  get f() { return this.registerForm.controls; }

  alertFn(data, type?) {
    this.alert = true;
    this.alertData = data;
    setTimeout(() => {
      this.alert = false;
      this.alertData = '';
    }, 3500);
    if (type) {
      this.alertType = false;
    } else {
      this.alertType = true;
    }
  }

  // reusable submit function add/update
  onSubmit(val?) {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    // resting appeal value to its default
    if (!this.registerForm.value.appealLevel) {
      this.registerForm.value.appealLevel = "0"
    }

    this.HttpConnector.postRequest(environment.Add_User, this.fromformIteration(this.registerForm.value)).subscribe(response => {
      this.usersList();
      // new user

      if (response.Result === ' Employee does not exist.') {
        this.alertFn(response['Result'], true);
        return;
      }
      if (!val) {
        this.deleteUserData = '';
        this.alertFn(response['Result']);
      } else { // update
        this.deleteUserData = '';
        this.alertFn(response['Result']);
      }
      this.reset(); // resetting form
    });
  }

  reset() {
    this.registerForm.reset();
    $("#checkboxx").prop("checked", false);
    this.deleteUserData = '';
  }

  usersList() {
    this.HttpConnector.getRequest(environment.Get_Auditors).subscribe(response => {
      this.users = this.toformIteration(response);
    });
  }

  toformIteration(data) {
    const value = [];
    data.forEach(ele => {
      const dataFormat = {
        id: ele['auditorId'],
        empId: ele['employee']['employeeId'],
        empFirstName: ele['employee']['firstName'],
        empLastName: ele['employee']['lastName'],
        role: ele['role'],
        reportingManager: ele['employee']['reportingManager'],
        auditType: ele['auditType'],
        probation: ele['employee']['probation'],
        employeeLocation: ele['employee']['empLocation'],
        preOrPost: ele['preOrPost'],
        post: ele['post'],
        payer: ele['payer']['payerShort'],
        state: ele['state'],
        lob: ele['lob'],
        appealLevel: ele['appealLevel'],
        emailId: ele['employee']['emailId']
      };
      value.push(dataFormat);
    });

    return value;

  }

  fromformIteration(ele) {
    const value = {
      auditorId: ele['id'],
      employee: {
        employeeId: ele['empId'],
        firstName: ele['empFirstName'],
        reportingManager: ele['reportingManager'],
        lastName: ele['empLastName'],
        emailId: '',
        probation: ele['probation'],
        empLocation: ele['employeeLocation'],
        status: 'Y'
      },
      role: ele['role'],
      auditType: ele['auditType'],
      preOrPost: ele['preOrPost'],
      post: ele['post'],
      lob: ele['lob'],
      appealLevel: ele['appealLevel'],
      state: ele['state'],
      payer: this.setPayer(ele['payer']),
      status: 'Y'
    };

    return value;
  }

  setPayer(shortName) {
    const payer = {
      payerId: 0,
      payerName: '',
      payerShort: ''
    };

    switch (shortName) {
      case 'ANTM':
        payer.payerId = 1;
        payer.payerName = 'ANTHEM';
        payer.payerShort = shortName;
        break;
      case 'BCBSMA':
        payer.payerId = 2;
        payer.payerName = 'Blue Cross Blue Shield of Massachusetts';
        payer.payerShort = shortName;
        break;
      case 'UHG':
        payer.payerId = 3;
        payer.payerName = 'UnitedHealth Group';
        payer.payerShort = shortName;
        break;

    }
    return payer;

  }

  // on edit send selected row values to form
  edit(val) {
    this.formReg(val);
  }

  delete() {
    this.HttpConnector.postRequest(environment.Delete_User, this.fromformIteration(this.deleteUserData)).subscribe(response => {
      this.alertFn(response['Result']);
      this.usersList();
      this.reset();
    });
  }

  /**get the selected option value */
  selectChangeHandler(event: any) {
    const selectedPayer = event.target.value;
    if (selectedPayer === 'ANTM') {
      this.states = [{ value: "New York", key: "New York" }]
      this.lobs = [{ value: "Medicaid", key: "Medicaid" }, { value: "Medicare", key: "Medicare" }];
      this.registerForm.get('lob').setValidators([Validators.required]);
      this.registerForm.get('state').setValue("")
      this.registerForm.get('lob').setValue("")
    } else if (selectedPayer === 'BCBSMA') {
      this.states = [{ value: "Massachusetts", key: "Massachusetts" }, { value: "New York", key: "New York" }];
      this.lobs = [{ value: "Medicaid", key: "Medicaid" }];
      this.registerForm.get('lob').setValidators([Validators.required]);
      this.registerForm.get('state').setValue("")
      this.registerForm.get('lob').setValue("")
    } else if (selectedPayer === 'UHG') {
      this.states = [{ value: "California", key: "California" }];
      this.lobs = [{ value: "Commercial/Other", key: "Commercial/Other" }];
      this.registerForm.get('lob').clearValidators();
      this.registerForm.get('lob').updateValueAndValidity();
      this.registerForm.get('state').setValue("")
      this.registerForm.get('lob').setValue("")
    }
  }
  /** ROLE CHAGNE HANDLER */
  roleChangeHandler(event: any) {
    if (event.target.value == 'Appeal Auditor') {
      this.registerForm.get('appealLevel').enable();
      this.registerForm.get('appealLevel').setValidators([Validators.required]);
    } else {
      this.registerForm.get('appealLevel').disable()
      this.registerForm.get('appealLevel').clearValidators();
      this.registerForm.get('appealLevel').setValue("0")
    }
  }
}
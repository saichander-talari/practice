import { Component, OnInit } from '@angular/core';
import { fadeInOut } from '../../router.animations';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
@Component({
  selector: 'app-transfer-work',
  templateUrl: './transfer-work.component.html',
  styleUrls: ['./transfer-work.component.scss'],
  animations: [fadeInOut()]
})
export class TransferWorkComponent implements OnInit {
  transferdata;
  dropdownVals = [];
  alert = false;
  alertData;
  toQ = '';
  auditorName = '';
  isQueueChecked = 'false';
  alertType = true;
  constructor(private HttpConnector: HttpConnectorService, public router: Router, ) {
    this.transferdata = JSON.parse(localStorage.getItem('transferdata'));
  }

  ngOnInit() {
    // get list of respective values (based on payers name and selected column in dashbord screen) to be populated in dropdowns
    this.getDropdownVals();
  }

  getDropdownVals() {
    this.HttpConnector.getRequest(environment.Transfer_Dropdown_values + [this.transferdata['payerId']]
      + '/' + this.transferdata['taskTypeId']).subscribe(response => {
        this.dropdownVals = response;
      });
  }

  submitTranfer() {
    // request format
    const values = {
      claimIds: this.transferdata['claimDetailKey'],
      fromQ: this.transferdata['taskTypeId'],
      toQ: Number(this.toQ),
      auditorId: Number(this.auditorName),
      isQueueChecked: this.isQueueChecked
    };
    this.HttpConnector.postRequest(environment.Transfer_Claims, values).subscribe(response => {
      if (response['successCount'] == 0) {
        this.alertType = false; // for alert background color (red)
      } else {
        this.alertType = true; // for alert background color (green)
      }
      if (response['operationType'] == "Auditor") {
        // No check box should be selected when user navigates to previous page after successful insert
        this.transferdata['claimDetailKey'] = [];
        localStorage.setItem('transferdata', JSON.stringify(this.transferdata));
      }
      this.alertFn(response['Result']);
    });
  }

  alertFn(data) {
    this.alert = true;
    this.alertData = data;
  }

  // radio button diasble logic
  radiofn(val) {
    this.isQueueChecked = val;
    this.toQ = '';
    this.auditorName = '';
  }
}

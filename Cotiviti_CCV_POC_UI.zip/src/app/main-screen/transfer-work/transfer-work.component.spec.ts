import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferWorkComponent } from './transfer-work.component';

describe('TransferWorkComponent', () => {
  let component: TransferWorkComponent;
  let fixture: ComponentFixture<TransferWorkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferWorkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

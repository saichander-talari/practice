import { Component, OnInit } from '@angular/core';
import { fadeInOut } from '../../router.animations';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: [fadeInOut()]
})
export class DashboardComponent implements OnInit {
  queues: any = [];

  constructor(private HttpConnector: HttpConnectorService, public router: Router) {
    localStorage.removeItem('transferdata');
  }

  ngOnInit() {
    this.payerList(); // get list
  }

  // request payers list
  payerList() {
    this.HttpConnector.getRequest(environment.Get_Queues).subscribe(response => {
      this.queues = Object.keys(response).map(i => response[i]);
    });
  }

  // Send Respective data to User Details page
  viewScreen(colName, payer, payerId, taskTypeId, columnCount) {
    if (columnCount > 0) {
      // this object is stored in localstorage and used next 2 cascading pages.
      const transferdata = {
        name: colName, //  colume name to be displayed
        count: 0, // number of queues
        queue: payer, // selected payer in array format
        payerId: payerId, // row id
        taskTypeId: taskTypeId, // column id
        claimDetailKey: [] // selected queues
      };
      if (payer.length > 0) {
        localStorage.setItem('transferdata', JSON.stringify(transferdata)); // setting localstorage with transferdata name
        this.router.navigate(['secure/queue-details']); // Navigate to queue details page
      }
    }

  }
}

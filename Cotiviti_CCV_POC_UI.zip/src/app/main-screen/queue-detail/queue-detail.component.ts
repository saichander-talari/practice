import { Component, OnInit } from '@angular/core';
import { HttpConnectorService } from '../../shared/services/http-connector.service';
import { environment } from '../../../environments/environment';
import { Router } from '@angular/router';
import { fadeInOut } from '../../router.animations';
@Component({
  selector: 'app-queue-detail',
  templateUrl: './queue-detail.component.html',
  styleUrls: ['./queue-detail.component.scss'],
  animations: [fadeInOut()]
})
export class QueueDetailComponent implements OnInit {
  transferdata;
  queueList;
  alert = false;
  alertData;
  checkAll = false;
  constructor(private HttpConnector: HttpConnectorService, public router: Router, ) {
    this.transferdata = JSON.parse(localStorage.getItem('transferdata')); // get localstorage data and assign to this variable
    this.transferdata['count'] = 0;
  }
  ngOnInit() {
    this.getQueueList(); // get queuelist
  }

  getQueueList() {
    this.HttpConnector.getRequest(environment.Get_Queue_Details + [this.transferdata['payerId']]
      + '/' + this.transferdata['taskTypeId']).subscribe(response => {
        this.queueList = this.checkbox(response); // sending to checkbox function to add checkbox functionality
        this.transferdata.count = this.queueList.length; // getting count of queues
      });
  }

  // Reusable function - this function is used for checkbox functionality, if there is selectAll then it check all the checkboxes
  // if there is checked list from forward screen (i.e if user selected list --> navigate to next page and returning back to this page)
  // then check box will be auto selected respectively
  checkbox(val, selectAll?) {
    const data = [];
    val.forEach(ele => {
      // debugger
      ele.checkbox = selectAll ? selectAll : false;
      if (selectAll === undefined && this.transferdata['claimDetailKey'].length > 0) {
        this.transferdata['claimDetailKey'].forEach(claimDetailKey => {
          if (this.transferdata['claimDetailKey'].length == val.length) {
            this.checkAll = true;
          } else {
            this.checkAll = false;
          }
          if (claimDetailKey == ele.claimDetailKey) {
            ele.checkbox = true;
          }
        });
      }
      data.push(ele);
    });
    return data;
  }

  selectAll() {
    this.checkAll = !this.checkAll;
    this.queueList = this.checkbox(this.queueList, this.checkAll);
  }

  // this sends data to next page with updated transferdata (local storage) object
  tranfer() {
    const vals = []; // sending ids
    // filtering ids
    this.queueList.filter(ele => {
      if (ele && ele.checkbox) {
        vals.push(ele.claimDetailKey);
      }
    });
    if (vals.length > 0) {
      this.transferdata.claimDetailKey = vals;
      localStorage.setItem('transferdata', JSON.stringify(this.transferdata));
      this.router.navigate(['secure/transfer-work']);
    } else {
      this.alertFn('Select at least 1 claim to perform this operation')
    }
  }

  // If selectall checkbox is checked/unchecked, then check/uncheck all rows
  checkFn() {
    this.checkAll = false;
    if (this.queueList.length === this.queueList.filter(ele => ele && ele.checkbox).length) {
      this.checkAll = true;
    }
  }

  // on close - delete localstorage and navigate to respective home page
  close() {
    localStorage.removeItem('transferdata');
    this.router.navigate(['secure/']);
  }
  alertFn(data) {
    this.alert = true;
    this.alertData = data;
  }
}

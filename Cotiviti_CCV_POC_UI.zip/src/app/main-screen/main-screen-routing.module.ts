import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserSetupComponent } from './user-setup/user-setup.component';
import { MainScreenComponent } from './main-screen.component';
import { QueueDetailComponent } from './queue-detail/queue-detail.component';
import { TransferWorkComponent } from './transfer-work/transfer-work.component';
const routes: Routes = [
  {
    path: '', component: MainScreenComponent, children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        component: DashboardComponent
      },
      {
        path: 'user-setup',
        component: UserSetupComponent
      },
      {
        path: 'queue-details',
        component: QueueDetailComponent
      },
      {
        path: 'transfer-work',
        component: TransferWorkComponent
      }
    ]
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MainScreenRoutingModule { }
import { Component, OnInit } from '@angular/core';
import { fadeInOut, routerTransition } from '../router.animations';
import { AuthService } from '../core/services/auth.service';
import { ActivatedRoute } from '@angular/router';
import { DataSharingService } from '../core/services/data-sharing.service';
@Component({
  selector: 'app-mainscreen',
  templateUrl: './main-screen.component.html',
  styleUrls: ['./main-screen.component.scss'],
  animations: [fadeInOut()]
})
export class MainScreenComponent implements OnInit {
  public isActive: boolean = true;

  constructor(private auth: AuthService, private route: ActivatedRoute, private dataSharedService: DataSharingService) { }
  ngOnInit() {
    this.auth.authToken = this.route.snapshot.data["token"];
    this.dataSharedService.test = "changed in dashboard"
  }
  sidebarActive(eventStatus) {
    this.isActive = eventStatus;
  }
}